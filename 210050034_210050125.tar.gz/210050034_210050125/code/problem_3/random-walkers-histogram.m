%Code for random walker simulation 

P = zeros(1,10000);          %Each element in "P' corresponds to position of a random walker 

rng(0);                      %Set the seed to 0
                             
for i=1:1000                 %In each iteration, all the walkers take a random step 

    r = zeros(1,10000);      %1x10000 array of zeros
    for j=1:10000            
        r(j) = sign(randn);  %assigning +1(forward) or -1(backward) to elements of r (creating the random step)
    end    
    P = P + 0.001*r;         %multiply r with 0.001(lenght of each step) and add it to P (updaing the final positions)
end

histogram(P,200);            %Plots the final posstions of all random walkers in 200 bins histogram

Emperical_mean = mean(P);    %claculates the emperical mean of final positins of the random wlakers
Variance = var(P);           %clalculate the variance in final positions of the random walkers

%Add varaince and mean to the graph
vartxt = "Variance : " + Variance;
emptxt = "Empirical mean : " + Emperical_mean;
str = {vartxt,emptxt};
text(0.03, 270, str,'Color','red');

%Add some properties to the graph
set(gca,"XGrid","off","YGrid","on")
title("Histogram of final positions of the random walkers ")
xlabel("final positions")
ylabel("frequency")