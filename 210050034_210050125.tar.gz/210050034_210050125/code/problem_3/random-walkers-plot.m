%Code for plotting the random walks

P = zeros(1000,1);               %stores the positions of a random walker in each of his 1000 steps

rng(0);                          %setting the seed to zero 

for i=1:1000                     %each iteration plot the path taken by a random walker 
    P(1)=0.001*sign(randn());    %finding the random first step    
    for j=2:1000                 %updating the position and store it in the matrix P
        r = sign(randn);         %+1 or -1 
        P(j) = P(j-1) + 0.001*r; %updating the position
    end      
    plot(P);                     %plotting the path 
    hold on;
end
hold off;

grid off
title("Plot of the paths")
xlabel("time")
ylabel("location")