function val = func_PMF(lambda, a)
    val = (lambda.^a).*exp(-lambda)./factorial(a);
end