
% This file prints theoretical PMF for values 0 to 25.
% It also plots them on graph.


rng(2);

lamy = 4;
p = 0.8;

lamz = lamy*p;

x = zeros(1,26);
y = zeros(1,26);

disp('z     PMF');

for z = 0:25
    x(z+1) = z;
    PMF = func_PMF(lamz, z);
    y(z+1) = PMF;
    string = [num2str(z), '   ', num2str(PMF)];
    disp(string);
end 

plot(x,y,'-^','MarkerSize',10, 'MarkerFaceColor','blue');
grid on;

t = title('Theoretical PMF for Poisson Thinning distribution');

