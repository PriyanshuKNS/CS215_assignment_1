% This file compares theoretical and empirical 
% Poisson thinning process.

rng(2);

lamy = 4;
p = 0.8;

lamz = lamy * p;

N = 10^5;

arr1 = poissrnd(lamy, 1, N);
arr2 = zeros(1,N);
for i = 1:N
    arr2(i) = binornd(arr1(i), p);
end

x = zeros(1,26);
y1 = zeros(1,26);
y2 = zeros(1,26);

q = 'z    experimental PMF       theoretical PMF';
disp(q);

for z = 0:25
    count = 0;
    for k = 1:N
            if arr2(k) == z
                count = count + 1;
            end
    end
   
    ePMF = count / N;
    tPMF = func_PMF(lamz, z); 

    x(z+1) = z;
    y1(z+1) = ePMF;
    y2(z+1) = tPMF;


    t = [num2str(z), '         ', num2str(ePMF),'           ',num2str(tPMF)];
    disp(t);
    
    hold on
end



plot(x,y1,'-s','MarkerSize',10, 'MarkerFaceColor','red');
plot(x,y2,'-^','MarkerSize',10, 'MarkerFaceColor','blue');



grid on;

t = title('Comparison of Empirical and Theoretical Poisson Thinning Distribution');

legend('Empirical PMF','Theoretical PMF','Location','best');
