% This file prints the theoretical PMF values
% of numbers from 0 to 25 and plots them.

lamx = 3;
lamy = 4;

lamz = lamx + lamy;

x = zeros(1,26);
y = zeros(1,26);

disp('z     PMF');

for z = 0:25
    x(z+1) = z;
    PMF = func_PMF(lamz, z);
    y(z+1) = PMF;
    string = [num2str(z), '   ', num2str(PMF)];
    disp(string);
end 

plot(x,y,'o','MarkerSize',10, 'MarkerFaceColor','red');
grid on;

t = title('Theoretical PMF for Poisson distribution');



