% It compares the empirical and theoretical PMF

rng(1);

lamx = 3;
lamy = 4;
lamz = lamx + lamy;

N = 10^6;
arrx = poissrnd(lamx, 1, N);
arry = poissrnd(lamy, 1, N);

arrz = arrx + arry;

x = zeros(1,26);
y1 = zeros(1,26);

y2 = zeros(1,26);


p = 'z    experimental PMF       theoretical PMF';
disp(p);

for z = 0:25
    count = 0;
    for k = 1:N
        if z == arrx(k) + arry(k)
            count = count + 1;
        end
    end

    tPMF = func_PMF(lamz, z);
    
    ePMF = count / N;
    t = [num2str(z), '          ', num2str(ePMF),'             ', num2str(tPMF)];
    disp(t);

    x(z+1) = z;
    y1(z+1) = ePMF;
    y2(z+1) = tPMF;

    hold on
end

plot(x,y1,'-s','MarkerSize',10, 'MarkerFaceColor','red');
plot(x,y2,'-^','MarkerSize',10, 'MarkerEdgeColor','blue');

txt = {'square : experimental', 'triangle: theoretical'};
text(15, 0.1, txt);

grid on;
t = title("Comparison of Empirical and Theoretical distribution");



