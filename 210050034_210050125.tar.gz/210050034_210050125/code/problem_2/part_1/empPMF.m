% This file prints empirical PMF for values from
% 0 to 25 and plots them.

rng(1);

lamx = 3;
lamy = 4;

N = 10^6;
arrx = poissrnd(lamx, 1, N);
arry = poissrnd(lamy, 1, N);

arrz = arrx + arry;

x = zeros(1,26);
y = zeros(1,26);


p = 'z    PMF';
disp(p);

for z = 0:25
    count = 0;
    for k = 1:N
        if z == arrx(k) + arry(k)
            count = count + 1;
        end
    end
   
    PMF = count / N;
    t = [num2str(z), '    ', num2str(PMF)];
    disp(t);

    x(z+1) = z;
    y(z+1) = PMF;
    
    hold on
end

plot(x,y, '.', 'MarkerSize', 20);
grid on;
t = title("Empirical PMF for Poisson Distribution");



