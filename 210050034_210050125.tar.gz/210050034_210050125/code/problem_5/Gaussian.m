%code for gaussian distribution

sz = [5 10 20 40 60 80 100 500 1000 10000];  %stores the sizes of the of the data set 
a = 0;                                       %a is mean of the given distribtuion
b = 1;                                       %b is variance of the given distribution
M = 100;                                     %number of times experiment is to be conducted
E = zeros(100,10);                           %In E, ith column contains all the errors of the conducted experiment with data set size = sz[i]
rng(0);                                      %set the seed to 0

for i=1:10                                   %each iteration conducts the the experiment with size sz[i]

    for j=1:M                                %starting the experiment
        R = normrnd(a,b,[sz(i) 1]);          %produces a set of real numbers drawn from the gaussian distribution with mean 0 and variance 1
        avg = mean(R);                       %calculates the average
        tru_mean = 0;                        %since a = 0
        E(j,i) = abs(avg - tru_mean);        %find the error and store it in E
    end      
end   
boxplot(E);                                   %plot the each column of the E

%Adding some properties to the graph
grid off
title("Box-Whisker-plot for gaussian distribution")
xlabel("size of the data sets")
ylabel("Distribution of errors")