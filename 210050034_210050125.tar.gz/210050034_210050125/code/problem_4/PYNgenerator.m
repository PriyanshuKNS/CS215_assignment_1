function val = PYNgenerator(N)
    
    val = 0;
    for i = 1:N
        val = val + PXgenerator();
    end

    val = val / N;
end