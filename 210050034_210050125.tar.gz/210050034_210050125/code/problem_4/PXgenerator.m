function val = PXgenerator()
    
    val = rand() - rand();

    if val >= 0
        val = 1 - val;
    else
        val = -1 - val;
    end

end