rng(1);

total_count = 10^5;
arr = zeros(1,total_count);

for i = 1:total_count
    arr(i) = PXgenerator();
end

cdfplot(arr);

title('Empirical CDF for P_X');