
rng(1);

N = 10^5;
arr = zeros(1, N);

for i = 1:10^5
    arr(i) = PXgenerator();
end

histogram(arr, 200);

t = title('Distribution for P(X)');