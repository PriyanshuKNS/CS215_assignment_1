rng(1);

func_histogramGeneratorPYN(8);