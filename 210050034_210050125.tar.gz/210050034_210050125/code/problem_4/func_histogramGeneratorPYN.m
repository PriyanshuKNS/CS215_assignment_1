function func_histogramGeneratorPYN(N)
    total_draws = 10^4;
    arr = zeros(1, total_draws);
    for i = 1:total_draws
        arr(i) = PYNgenerator(N);
    end

    histogram(arr, 200);
    txt = "Histogram of P_Y for N = " + N;
    t = title(txt);
end