rng(1);

func_cdf_pyN(2);
hold on;
func_cdf_pyN(4);
func_cdf_pyN(8);
func_cdf_pyN(16);
func_cdf_pyN(32);
func_cdf_pyN(64);

legend('N = 2','N = 4','N = 8','N = 16','N = 32','N = 64','Location','best');

title('Empirical CDF for different values of N');