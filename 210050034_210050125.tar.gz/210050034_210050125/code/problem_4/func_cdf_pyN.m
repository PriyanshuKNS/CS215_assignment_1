function func_cdf_pyN(N)
      total_count = 10^4;
      arr = zeros(1,total_count);

      for i = 1:total_count
          arr(i) = PYNgenerator(N);
      end

      cdfplot(arr);
end