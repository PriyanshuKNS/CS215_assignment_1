% PDF function

function val = func_pdf(x,u,b)
    p = (x-u)/b;
    val = 1./(pi*b*(1 + p.^2));
end






