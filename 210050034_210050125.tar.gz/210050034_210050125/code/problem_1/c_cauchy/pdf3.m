% Plotting PDF function of Cauchy distribution

x = linspace(-5,5);

y1 = func_pdf(x, 0, 1);
p = plot(x,y1, '-r');
ylim([0,0.70]);

str = {'x_0 = 0', '\gamma = 1'};
text(2, 0.5, str, 'Color', 'red','FontSize',20);
t = title('Cauchy PDF');
