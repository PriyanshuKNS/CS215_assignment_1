% PDF function

function val = func_pdf(x,u,b)
    p = (x-u)/b;
    val = exp(-p-exp(-p))/b;
end






