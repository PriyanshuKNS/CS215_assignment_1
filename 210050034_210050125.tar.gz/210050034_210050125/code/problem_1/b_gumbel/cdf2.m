% Plotting CDF of Gumbel distribution

x = linspace(-5, 20);
c1 = func_cdf(-100, x, 10000, 1, 2);

p1 = plot(x,c1, '-b');
ylim([0,1]);

str = {'\mu = 1', '\beta = 2'};
text(15, 0.80, str, 'Color', 'blue','FontSize',20);
title('Gumbel CDF');



% Printing variance
var = func_variance(-100, 100, 1000, 2, 2);
disp(var);
