% Plotting PDF of Gumbel distribution

x = -5:0.01:20;
y1 = func_pdf(x, 1, 2);

p = plot(x,y1, '-b');
ylim([0,0.20]);

str = {'\mu = 1', '\beta = 2'};
text(15, 0.16, str, 'Color', 'blue','FontSize',20);
title('Gumbel PDF');
