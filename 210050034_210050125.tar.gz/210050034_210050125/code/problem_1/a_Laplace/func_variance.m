% Variance function 
% It uses PDF function and two parameters.


function variance = func_variance(x1, x2, n, u, b)
    mean = 0;
    for i = 0:n
        x = x1 + ((x2-x1)*i)/n;
        mean = mean + x.*func_pdf(x, u, b).*((x2-x1)/n);
    end

    variance = 0;
    for i = 0:n
        x = x1 + ((x2-x1)*i)/n;
        variance = variance + (x.^2).*func_pdf(x, u, b).*((x2-x1)/n);
    end
    variance = variance - mean.^2;
end