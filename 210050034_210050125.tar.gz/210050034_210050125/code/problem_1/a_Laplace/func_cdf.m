% Function to calculate CDF using PDF and two parameters
% CDF is calculated using Reimann sum approximation

function val = func_cdf(x1,x2,n,u,b)
    val = 0;
    for i = 0:n
        val = val + func_pdf(x1 + ((x2-x1)*i)/n, u, b).*((x2-x1)/n);
    end
end
