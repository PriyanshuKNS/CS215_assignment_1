% PDF function

function val = func_pdf(x,u,b)
    val = exp(-abs(x-u)/b) / (2*b);
end






