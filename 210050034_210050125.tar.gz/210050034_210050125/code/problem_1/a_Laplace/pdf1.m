% Plotting PDF of Laplace distribution

x = linspace(-10, 10);
y1 = func_pdf(x, 2, 2);

p1 = plot(x,y1, '-r');
ylim([0,0.5]);

str = {'\mu = 2', 'b = 2'};
text(5, 0.4, str, 'Color', 'red','FontSize',20);

title('Laplace PDF');


