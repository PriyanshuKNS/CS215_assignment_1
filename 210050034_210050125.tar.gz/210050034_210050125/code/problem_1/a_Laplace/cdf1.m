% Plotting CDF of Laplace distribution

x = linspace(-10, 10);
c1 = func_cdf(-100, x, 1000, 2, 2);

p1 = plot(x,c1, '-r');
ylim([0,1]);

str = {'\mu = 2', 'b = 2'};
text(3, 0.4, str, 'Color', 'red','FontSize',20);
title('Laplace CDF');



% Printing variance of Laplace distribution
var = func_variance(-100, 100, 1000, 2, 2);
disp(var);





